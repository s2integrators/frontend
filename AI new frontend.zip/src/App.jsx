// filepath: src/App.jsx
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Dashboard from "./pages/Dashboard";
import InterviewRoom from "./pages/InterviewRoom";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Default route */}
        <Route path="/" element={<Dashboard />} />

        {/* Interview room route */}
        <Route path="/interview-room/:roomId" element={<InterviewRoom />} />

      </Routes>
    </BrowserRouter>
  );
}
